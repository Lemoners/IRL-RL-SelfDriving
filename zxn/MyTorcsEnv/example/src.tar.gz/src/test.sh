#! /bin/bash
echo "test"
sleep 1
xdotool search --name "/usr/local/lib/torcs/torcs-bin" key Return
sleep 0.1
xdotool search --name "/usr/local/lib/torcs/torcs-bin" key Return
sleep 0.1
xdotool search --name "/usr/local/lib/torcs/torcs-bin" key Up
sleep 0.1
xdotool search --name "/usr/local/lib/torcs/torcs-bin" key Up
sleep 0.1
xdotool search --name "/usr/local/lib/torcs/torcs-bin" key Return
sleep 0.1
xdotool search --name "/usr/local/lib/torcs/torcs-bin" key Return
